#!/bin/bash
make clean
make
./Build/skeleton
